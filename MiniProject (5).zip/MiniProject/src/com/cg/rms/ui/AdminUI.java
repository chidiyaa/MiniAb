/*package com.cg.rms.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.service.PlacedCandidateService;
import com.cg.rms.service.PlacedCandidateServiceImpl;
import com.cg.rms.service.ValidationService;
public class AdminUI {
    static PlacedCandidateService pcService=null;
    public static void main(String[] args) throws RecruitmentException{
        String uname;
        String password;
        System.out.println("****Enter Admin Username*****");
        Scanner sc=new Scanner(System.in);
        uname=sc.next();
        System.out.println("****Enter Admin Password*****");
        password=sc.next();
        ValidationService vService=new ValidationService();
        boolean validatelogin=vService.validateAdmin(uname,password);//rename method
        while(true){
            System.out.println("Welcome.....");
            System.out.println("What do you want to do?");
            System.out.println(" 1:Count of individuals  placed in a particular month \n "
                    + "2:Count of individuals  placed in a particular company \n "
                    + "3:Count of individuals placed in a particular position(designation)\n"+
                     " 4:Exit");
            System.out.println("Enter ur choice");
            int choice=0;
            choice=sc.nextInt();
            pcService=new PlacedCandidateServiceImpl();
            switch(choice)
            {
            case 1:countpcmonth(); break;
            case 2:countpccompany();break;
            case 3:countpcposition();break;
            case 6:System.exit(0);
default:System.out.println("Invalid input");

            }
            }
        
        
    }
    private static void countpcposition() {
        Scanner sc=new Scanner(System.in);
        int count;
        try {
            System.out.println("Enter designation");
            String designation =sc.next();
            count=pcService.pCountDesignation(designation);
            System.out.println("Total candidates placed as "+designation +" is "+count);
        } catch (RecruitmentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        
    }
    private static void countpccompany() {
        Scanner sc=new Scanner(System.in);
        int count;
        try {
            System.out.println("Enter Company");
            String company =sc.next();
            count=pcService.pCountCompany(company);
            System.out.println("Total candidates placed in"+company +" is "+count);
        } catch (RecruitmentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }
    private static void countpcmonth() {
        Scanner sc=new Scanner(System.in);
        int count;
        try {
            System.out.println("Enter month");
            String month =sc.next();
            count=pcService.pCountMonth(month);
            System.out.println("Total candidates placed in"+month +" is "+count);
        } catch (RecruitmentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }
}*/