package com.cg.rms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.rms.beans.CandidateLogin;
import com.cg.rms.beans.CompanyUser;

import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.util.DBUtil;

public class LoginDaoImpl implements LoginDao {

	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	ResultSet rs2=null;
	ResultSet rs3=null;

public ArrayList<CandidateLogin> getCandidateLogin() throws RecruitmentException
{
	ArrayList<CandidateLogin> jobReqList=new ArrayList<CandidateLogin>();
	//JobRequirements company=new JobRequirements();
	try
	{
		con=DBUtil.getConn();
		String selectqry1="SELECT *FROM Candidate_Login ";
		st=con.createStatement();
		rs=st.executeQuery(selectqry1);
		while(rs.next())
		{
			CandidateLogin company=new CandidateLogin(rs.getString(1),rs.getString(2),
				rs.getString(3));
			
					
			jobReqList.add(company);
		}

	}
	catch(Exception e)
	{
		
		e.printStackTrace();
		throw new RecruitmentException(e.getMessage());
	}
	finally
	{
		try {
			st.close();
			rs.close();
			con.close();
		}
		catch (SQLException e) {

			throw new RecruitmentException(e.getMessage());
		}
}
	
	return jobReqList;
}
public ArrayList<CompanyUser> getCompanyLogin() throws RecruitmentException
{
	ArrayList<CompanyUser> jobReqList=new ArrayList<CompanyUser>();
	//JobRequirements company=new JobRequirements();
	try
	{
		con=DBUtil.getConn();
		String selectqry1="SELECT *FROM Company_User ";
		st=con.createStatement();
		rs=st.executeQuery(selectqry1);
		while(rs.next())
		{
			CompanyUser company=new CompanyUser(rs.getString(1),rs.getString(2),
				rs.getString(3));
			
					
			jobReqList.add(company);
		}

	}
	catch(Exception e)
	{
		
		e.printStackTrace();
		throw new RecruitmentException(e.getMessage());
	}
	finally
	{
		try {
			st.close();
			rs.close();
			con.close();
		}
		catch (SQLException e) {

			throw new RecruitmentException(e.getMessage());
		}
}
	
	return jobReqList;
}
}
