package com.cg.rms.dao;

import java.util.ArrayList;

import com.cg.rms.beans.CandidateLogin;
import com.cg.rms.beans.CompanyUser;
import com.cg.rms.exception.RecruitmentException;

public interface LoginDao {
	public ArrayList<CompanyUser> getCompanyLogin() throws RecruitmentException;
	public ArrayList<CandidateLogin> getCandidateLogin() throws RecruitmentException;

}
