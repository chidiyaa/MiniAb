package com.cg.rms.service;

import java.util.ArrayList;

import com.cg.rms.beans.Company;
import com.cg.rms.beans.CompanyMaster;
import com.cg.rms.beans.CompanyUser;
import com.cg.rms.beans.PlacedCandidate;
import com.cg.rms.dao.CompanyUserDAO;
import com.cg.rms.dao.CompanyUserDAOImpl;
import com.cg.rms.dao.PlacedCandidateDAO;
import com.cg.rms.dao.PlacedCandidateImpl;
import com.cg.rms.exception.RecruitmentException;

public class PlacedCandidateServiceImpl implements PlacedCandidateService {

	PlacedCandidateDAO pcdao=new PlacedCandidateImpl();
	CompanyUserDAO cudao=new CompanyUserDAOImpl() ;
	@Override
	public int pCountMonth(String month) throws RecruitmentException {
		ArrayList<PlacedCandidate> pmon=pcdao.searchPlaced();
		int count=0;
		
		for(PlacedCandidate pc:pmon)
		{
			if(month.equalsIgnoreCase(pc.getMonth()))
				count++;
			
		}
		return count;
	}

	@Override
	public int pCountCompany(String Company) throws RecruitmentException {
		ArrayList<PlacedCandidate> pcom=pcdao.searchPlaced();
		ArrayList<CompanyMaster> cuser=cudao.getCompanyDetails();
		int count=0;
		
		for(CompanyMaster c:cuser)
		{
			for(PlacedCandidate pc:pcom)
			{
				
				if(c.getCompanyId().equals(pc.getCompanyId())
				&&Company.equalsIgnoreCase(c.getCompanyName()))
				{
					count++;
					
				}
			}
		}
		return count;
	}

	@Override
	public int pCountDesignation(String designation)
			throws RecruitmentException {
		ArrayList<PlacedCandidate> pdes=pcdao.searchPlaced();
		int count=0;
		
		for(PlacedCandidate pc:pdes)
		{
			if(designation.equalsIgnoreCase(pc.getDesignation()))
				count++;
			
		}
		return count;
		
	}

	

}
