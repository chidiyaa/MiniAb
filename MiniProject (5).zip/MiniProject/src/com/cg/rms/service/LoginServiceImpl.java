package com.cg.rms.service;

import java.util.ArrayList;

import com.cg.rms.beans.CandidateLogin;
import com.cg.rms.beans.CompanyUser;
import com.cg.rms.dao.LoginDao;
import com.cg.rms.dao.LoginDaoImpl;
import com.cg.rms.exception.RecruitmentException;

public class LoginServiceImpl implements LoginService {
LoginDao ldao=new LoginDaoImpl();
	@Override
	public ArrayList<CompanyUser> getCompanyLogin() throws RecruitmentException {
		// TODO Auto-generated method stub
		return ldao.getCompanyLogin();
	}

	@Override
	public ArrayList<CandidateLogin> getCandidateLogin()
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return ldao.getCandidateLogin();
	}

}
