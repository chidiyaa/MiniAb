package com.cg.rms.service;

import java.util.ArrayList;

import com.cg.rms.beans.CandidateLogin;
import com.cg.rms.beans.CompanyUser;
import com.cg.rms.exception.RecruitmentException;


public interface LoginService {
	public ArrayList<CompanyUser> getCompanyLogin() throws RecruitmentException;
	public ArrayList<CandidateLogin> getCandidateLogin() throws RecruitmentException;

}
